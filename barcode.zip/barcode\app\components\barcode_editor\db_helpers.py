"""Database helper functions for the barcode editor (LOOKUP type).

Data is sourced from mmsdgr (Master Source Data Group) records.

Key facts from the actual repos:
  - fetch_all_mmsdgr()  -> fields is a comma-separated STRING of field NAMES
                           (from string_agg(fld.mtflnm, ', '))
  - fetch_tables_by_connection(conn_name) -> uses connection NAME as PK (not int)
  - connection_id in mmsdgr is the connection NAME string (mcconm)
  - table_id in mmsdgr is the table NAME string (mttbnm)
"""


def _fetch_connections() -> list[dict]:
    """
    Return distinct connection names that appear in mmsdgr source data records.
    Each entry is {pk: conn_name, name: conn_name}.
    """
    try:
        from repositories.mmsdgr_repo import fetch_all_mmsdgr
        from repositories.mconnc_repo import fetch_connections_by_engine
        from repositories.mengin_repo import fetch_all_engines

        # Build full set of valid connection names and a id->name map
        engines = fetch_all_engines()
        valid_conn_names: set[str] = set()
        conn_id_to_name: dict = {}
        for engine in engines:
            conns = fetch_connections_by_engine(engine["pk"])
            for c in conns:
                valid_conn_names.add(c["name"])
                conn_id_to_name[c["pk"]]   = c["name"]
                conn_id_to_name[c["name"]] = c["name"]

        records = fetch_all_mmsdgr()
        seen: set[str] = set()
        result: list[dict] = []

        for r in records:
            cid = r.get("connection_id")
            name = conn_id_to_name.get(cid) or (str(cid).strip() if cid else "")
            if name and name in valid_conn_names and name not in seen:
                seen.add(name)
                result.append({"pk": name, "name": name})

        return sorted(result, key=lambda x: x["name"])

    except Exception as e:
        import traceback
        print(f"[_fetch_connections] {e}")
        traceback.print_exc()
        return []


def _fetch_tables_for_connection(connection_name: str) -> list[dict]:
    """
    Return distinct table names from mmsdgr records for the given connection.
    Each entry is {pk: table_name, name: table_name}.
    """
    try:
        from repositories.mmsdgr_repo import fetch_all_mmsdgr
        from repositories.mconnc_repo import fetch_connections_by_engine
        from repositories.mengin_repo import fetch_all_engines

        # Build conn_id -> conn_name map
        engines = fetch_all_engines()
        conn_id_to_name: dict = {}
        for engine in engines:
            conns = fetch_connections_by_engine(engine["pk"])
            for c in conns:
                conn_id_to_name[c["pk"]]   = c["name"]
                conn_id_to_name[c["name"]] = c["name"]

        records = fetch_all_mmsdgr()
        seen: set[str] = set()
        result: list[dict] = []

        for r in records:
            cid = r.get("connection_id")
            resolved = conn_id_to_name.get(cid) or (str(cid).strip() if cid else "")
            if resolved != connection_name:
                continue

            # table_id is the table name string (mttbnm used as PK)
            tname = str(r.get("table_id") or "").strip()
            if tname and tname not in seen:
                seen.add(tname)
                result.append({"pk": tname, "name": tname})

        return sorted(result, key=lambda x: x["name"])

    except Exception as e:
        import traceback
        print(f"[_fetch_tables_for_connection] {e}")
        traceback.print_exc()
        return []


def _fetch_fields_for_table(table_name: str) -> list[str]:
    """
    Return field names from mmsdgr records for the given table.

    fetch_all_mmsdgr() returns `fields` as a comma-separated string of field
    NAMES (via string_agg(fld.mtflnm, ', ')), so no ID resolution needed.
    """
    try:
        from repositories.mmsdgr_repo import fetch_all_mmsdgr

        records = fetch_all_mmsdgr()
        seen: set[str] = set()
        result: list[str] = []

        for r in records:
            tname = str(r.get("table_id") or "").strip()
            if tname != table_name:
                continue

            raw = r.get("fields") or ""
            if isinstance(raw, str):
                names = [f.strip() for f in raw.split(",") if f.strip()]
            elif isinstance(raw, (list, tuple)):
                names = [str(f).strip() for f in raw if f]
            else:
                names = []

            for name in names:
                if name and name not in seen:
                    seen.add(name)
                    result.append(name)

        return sorted(result)

    except Exception as e:
        import traceback
        print(f"[_fetch_fields_for_table] {e}")
        traceback.print_exc()
        return []


def _parse_fields_from_query(query: str) -> list[str]:
    """
    Parse SELECT column expressions from a raw SQL query string.
    Returns items like ["mbflag AS flag", "mbnobr", "mbnama AS name", "mbcase"].
    Falls back to empty list if query is blank or unparseable.
    """
    if not query or not query.strip():
        return []
    try:
        import re
        q = query.strip()
        # Extract the SELECT ... FROM portion
        m = re.search(r'(?i)SELECT\s+(.*?)\s+FROM\b', q, re.DOTALL)
        if not m:
            # Maybe it's just a column list without SELECT/FROM
            col_str = q
        else:
            col_str = m.group(1)
        # Split by comma, ignoring commas inside parentheses
        depth, current, parts = 0, [], []
        for ch in col_str:
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
            if ch == ',' and depth == 0:
                parts.append(''.join(current).strip())
                current = []
            else:
                current.append(ch)
        if current:
            parts.append(''.join(current).strip())
        return [p for p in parts if p]
    except Exception:
        return []


def _fetch_barcode_types() -> list[str]:
    """
    Return barcode type display names (BRBART) from barcodesap.mbarty,
    ordered alphabetically. Falls back to a hardcoded list on any error.
    """
    _FALLBACK = [
        "AZTEC (2D)", "CODE 11", "CODE 128", "CODE 128-A", "CODE 128-B",
        "CODE 128-C", "CODE 39", "CODE 93", "DATA MATRIX (2D)", "EAN 13",
        "EAN 8", "INTERLEAVED 2 OF 5", "QR (2D)", "UPC A",
    ]
    try:
        from repositories.mbarty_repo import fetch_all_mbarty
        rows = fetch_all_mbarty()
        names = [r["name"].strip() for r in rows if r.get("name", "").strip()]
        return names if names else _FALLBACK
    except Exception as e:
        import traceback
        print(f"[_fetch_barcode_types] {e}")
        traceback.print_exc()
        return _FALLBACK